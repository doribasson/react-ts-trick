import React, { useEffect, useRef } from "react";

const App: React.FC = () => {
  const timerRef = useRef<number>(0); // Stores the current value of the timer
  const timerElementRef = useRef<HTMLSpanElement | null>(null); // Reference to the DOM element displaying the timer
  const intervalRef = useRef<NodeJS.Timeout | null>(null); // Reference to the interval

  // Function to start the timer
  const startTimer = () => {
    intervalRef.current = setInterval(() => {
      timerRef.current += 1; // Increment the timer

      // Update the DOM directly
      if (timerElementRef.current) {
        timerElementRef.current.textContent = timerRef.current.toString();
      }
    }, 1000);
  };

  // Function to stop the timer
  const stopTimer = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current); // Clear the interval to stop the timer
    }
  };

  // Reset the timer
  const resetTimer = () => {
    timerRef.current = 0; // Reset the timer value to 0
    if (timerElementRef.current) {
      timerElementRef.current.textContent = "0"; // Update the displayed value
    }
  };

  // Initialize the timer when the component mounts
  useEffect(() => {
    startTimer(); // Start the timer when the component mounts

    // Cleanup the interval on unmount
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []); // Empty dependency array means this effect runs only once when the component mounts

  return (
    <div className="container">
      <div className="box">
        <div className="circle">
          <span ref={timerElementRef} className="timer">0</span>
        </div>
        <div className="buttons">
          {/* Checkbox for toggling Stop/Resume */}
          <input type="checkbox" id="toggleTimer" className="toggle-checkbox" />
          <label htmlFor="toggleTimer" className="toggle-label">
            <span className="button button-yellow">Resume</span>
            <span className="button button-yellow">Stop</span>
          </label>

          <button onClick={resetTimer} className="button button-red">
            Reset Timer
          </button>
        </div>
      </div>
    </div>
  );
};

export default App;
